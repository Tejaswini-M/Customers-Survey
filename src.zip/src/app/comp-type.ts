import { Item } from './item';

export class CompType {
  component: any;
  data: any;
}