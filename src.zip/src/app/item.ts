export class Item {
    comp!: number;
    qns!: string;
    ans!: string;
  }